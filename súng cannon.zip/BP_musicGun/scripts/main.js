import { world, system, ItemStack } from "@minecraft/server";

// Lắng nghe sự kiện người chơi dùng Item (Nhấp chuột phải / Bấm nút Dùng)
world.afterEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const itemStack = event.itemStack;

  // Kiểm tra nếu item đang cầm chính là Súng Cannon
  if (itemStack && itemStack.typeId === "custom:canon_gun") {
    const headLocation = player.getHeadLocation();
    const viewVector = player.getViewDirection();

    // Tính toán vị trí xuất phát đạn (ngay trước mặt người chơi)
    const spawnLocation = {
      x: headLocation.x + viewVector.x * 1.5,
      y: headLocation.y + viewVector.y * 1.5,
      x: headLocation.z + viewVector.z * 1.5
    };

    // 1. Tạo quả đạn bắn ra (Ví dụ: Fireball / Small Fireball)
    const projectile = player.dimension.spawnEntity("minecraft:small_fireball", spawnLocation);
    
    // Gán vận tốc để đạn bay theo hướng người chơi nhìn
    const speed = 2.5;
    projectile.applyImpulse({
      x: viewVector.x * speed,
      y: viewVector.y * speed,
      z: viewVector.z * speed
    });

    // 2. Phát âm thanh tiếng pháo nổ / tiếng bắn
    player.dimension.playSound("random.explode", player.location, {
      volume: 1.0,
      pitch: 0.8
    });

    // 3. Trừ độ bền của súng sau mỗi lần bắn (Nếu chơi chế độ sinh tồn)
    if (player.getGameMode() !== "creative") {
      const equipment = player.getComponent("minecraft:equippable");
      if (equipment) {
        const mainhand = equipment.getEquipment("Mainhand");
        const durability = mainhand.getComponent("minecraft:durability");

        if (durability) {
          if (durability.damage + 1 >= durability.maxDurability) {
            // Hỏng súng -> Xóa súng
            equipment.setEquipment("Mainhand", undefined);
            player.dimension.playSound("random.break", player.location);
          } else {
            // Trừ 1 điểm độ bền
            durability.damage += 1;
            equipment.setEquipment("Mainhand", mainhand);
          }
        }
      }
    }
  }
});